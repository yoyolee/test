package ParallelTest;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.Scanner;

public class Starter {
	public static void main (String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of random gaussian number to generate:");
		int loop= sc.nextInt();
		double time = System.nanoTime()/1000000000.0;
		String path = "C:/Users/yoyo/Documents/visual studio 2012/Projects/Project1/Release";
		String[] cmd={path+"/mpiexec","-n","8",path+"/Project1.exe", ""+loop};
        Process p = Runtime.getRuntime().exec(cmd);
        BufferedReader in = new BufferedReader(
        					new InputStreamReader(p.getInputStream()));
        String line =null;
        while((line=in.readLine())!=null){
        	System.out.println(line);
        }
        p.waitFor();
        time = System.nanoTime()/1000000000.0-time;
        System.out.println("Parallel Method java time = "+time+" seconds");
        time = System.nanoTime()/1000000000.0;
        randomGenerator(loop);
        time = System.nanoTime()/1000000000.0-time;
        System.out.println("Sequential Method time = "+time+" seconds");
	}
	public static void randomGenerator(int loop){
		Random r = new Random();
		for(int i=0;i<loop;i++){
			r.nextGaussian();
		}
	}
}
