! -*- Mode: F77; F90; -*-
!
!      (C) Microsoft Corporation.
!
       INTEGER MPI_AINT
       PARAMETER (MPI_AINT=z'4c00083b')
